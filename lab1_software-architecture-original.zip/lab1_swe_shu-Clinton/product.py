from fastapi import FastAPI

# Initialize the FastAPI app
app = FastAPI()

# Sample product catalog (mock database)
product_catalog = [
    {"id": 1, "name": "Laptop", "price": 1000},
    {"id": 2, "name": "Smartphone", "price": 500},
    {"id": 3, "name": "Tablet", "price": 300},
]

@app.get("/items")
def list_products():
    """Fetch and return the list of all available products."""
    return {"items": product_catalog}

@app.get("/items/{product_id}")
def retrieve_product(product_id: int):
    """Fetch the details of a single product based on its ID."""
    product_found = next((item for item in product_catalog if item["id"] == product_id), None)
    if product_found:
        return product_found
    return {"message": "Product not found"}, 404
