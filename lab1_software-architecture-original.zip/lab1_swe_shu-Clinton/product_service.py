from fastapi import FastAPI

# Create the FastAPI app instance
app = FastAPI()

# In-memory database for product information
product_inventory = [
    {"id": 1, "name": "Laptop", "price": 1000},
    {"id": 2, "name": "Smartphone", "price": 500},
    {"id": 3, "name": "Tablet", "price": 300},
]

@app.get("/items")
def list_all_products():
    """Fetch all available products from the inventory."""
    return {"items": product_inventory}

@app.get("/items/{item_id}")
def fetch_product_details(item_id: int):
    """Retrieve the details of a specific product by its ID."""
    selected_product = next((item for item in product_inventory if item["id"] == item_id), None)
    if selected_product:
        return selected_product
    return {"message": "Product not found"}, 404
