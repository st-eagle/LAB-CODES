from fastapi import FastAPI

# Initialize FastAPI app
app = FastAPI()

# Sample data representing users from Cameroon
user_data = [
    {"id": 1, "name": "Emmanuel Nji", "email": "emmanuel.nji@cameroon.com"},
    {"id": 2, "name": "Amina Fomum", "email": "amina.fomum@cameroon.com"},
    {"id": 3, "name": "Kwame Nkuo", "email": "kwame.nkuo@cameroon.com"},
]

@app.get("/accounts")
def list_all_users():
    """Get a list of all users."""
    return {"accounts": user_data}

@app.get("/accounts/{user_id}")
def retrieve_user_details(user_id: int):
    """Fetch details for a specific user by their ID."""
    found_user = next((user for user in user_data if user["id"] == user_id), None)
    if found_user:
        return found_user
    return {"message": "User not found"}, 404
