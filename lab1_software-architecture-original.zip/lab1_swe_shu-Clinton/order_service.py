from fastapi import FastAPI
import requests

# Initialize FastAPI application
app = FastAPI()

# In-memory storage for all orders
order_list = []

# Product Service URL
PRODUCT_API_URL = "http://product-service.default.svc.cluster.local:80/products"


@app.post("/place-order")
def place_order(product_id: int, quantity: int):
    """Place an order for a specific product."""
    # Retrieve product details from the Product API
    response = requests.get(f"{PRODUCT_API_URL}/{product_id}")

    if response.status_code != 200:
        return {"error_message": "Product not found"}, 404

    product_details = response.json()
    total_amount = product_details["price"] * quantity
    new_order = {
        "product_id": product_id,
        "quantity": quantity,
        "total_amount": total_amount
    }

    # Add the new order to the list of orders
    order_list.append(new_order)

    return {"status": "Order placed successfully", "order_details": new_order}


@app.get("/view-orders")
def view_orders():
    """Fetch and return all placed orders."""
    return {"all_orders": order_list}
